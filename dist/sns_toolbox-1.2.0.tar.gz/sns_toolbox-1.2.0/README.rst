""""""""""""
SNS-Toolbox
""""""""""""

Documentation is available on `ReadTheDocs <https://sns-toolbox.readthedocs.io/en/latest/index.html>`_:

.. image:: https://readthedocs.org/projects/sns-toolbox/badge/?version=latest
    :target: https://sns-toolbox.readthedocs.io/en/latest/?badge=latest
    :alt: Documentation Status


Install using pip:
::
    pip install sns-toolbox

Tutorial 6 uses the python package for OpenCV, please see its `installation instructions <https://pypi.org/project/opencv-python/>`_.